define([ "backbone","app" ], function(Backbone,app) {
	
	var investorTransactionDetailCollection = Backbone.Collection.extend({

		initialize: function (model, options) {
            
	    }
	});

	return investorTransactionDetailCollection;

})