define([ "backbone" ], function(Backbone) {
	
	var vendorServicesCollection = Backbone.Collection.extend({

		initialize: function (model, options) {
	    }
	});

	return vendorServicesCollection;

})