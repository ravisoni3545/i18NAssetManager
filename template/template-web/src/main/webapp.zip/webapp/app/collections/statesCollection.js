define([ "backbone" ], function(Backbone) {
	
	var statesCollection = Backbone.Collection.extend({

		initialize: function (model, options) {
	    }
	});

	return statesCollection;

})