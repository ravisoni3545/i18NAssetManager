define([ "backbone" ], function(Backbone) {
	
	var lendersCollection = Backbone.Collection.extend({

		initialize: function (model, options) {
	    }
	});

	return lendersCollection;

})