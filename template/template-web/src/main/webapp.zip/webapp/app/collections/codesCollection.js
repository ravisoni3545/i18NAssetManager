define([ "backbone" ], function(Backbone) {
	
	var codesCollection = Backbone.Collection.extend({

		initialize: function (model, options) {
	    }
	});

	return codesCollection;

})