define([ "backbone" ], function(Backbone) {
	
	var servicesCollection = Backbone.Collection.extend({

		initialize: function (model, options) {
	    }
	});

	return servicesCollection;

})