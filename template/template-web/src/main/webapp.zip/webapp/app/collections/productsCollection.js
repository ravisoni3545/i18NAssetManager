define([ "backbone" ], function(Backbone) {
	
	var productsCollection = Backbone.Collection.extend({

		initialize: function (model, options) {
	    }
	});

	return productsCollection;

})