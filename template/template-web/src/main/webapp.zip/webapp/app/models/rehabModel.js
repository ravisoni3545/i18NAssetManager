define([ "backbone", "app" ], function(Backbone, app) {
	var RehabModel = Backbone.Model.extend({

	
	

	});

	return RehabModel;

})