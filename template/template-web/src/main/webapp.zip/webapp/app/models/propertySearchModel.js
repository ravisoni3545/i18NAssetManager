define([ "backbone", "app" ], function(Backbone, app) {
	var propertySearchModel = Backbone.Model.extend({


	});

	return propertySearchModel;

});