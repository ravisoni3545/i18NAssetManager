define(["backbone", "app"],function(Backbone, app){
	var AMAgreementsModel=Backbone.Model.extend({
		defaults : {
		}
	});
	return AMAgreementsModel;

})