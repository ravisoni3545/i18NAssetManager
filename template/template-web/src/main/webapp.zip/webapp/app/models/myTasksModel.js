define([ "backbone", "app" ], function(Backbone, app) {
	var myTaskModel = Backbone.Model.extend({

		initialize: function () {

        },
		defaults : {
		}
		
	});

	return myTaskModel;

});