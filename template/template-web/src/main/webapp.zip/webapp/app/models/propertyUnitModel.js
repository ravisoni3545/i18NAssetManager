define(["backbone", "app"],function(Backbone, app){
	var propertyUnitModel=Backbone.Model.extend({
		defaults : {
		}
	});
	return propertyUnitModel;
});