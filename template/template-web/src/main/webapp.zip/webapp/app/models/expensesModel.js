define(["backbone", "app"],function(Backbone, app){
	var ExpensesModel=Backbone.Model.extend({
		defaults : {
		}
	});
	return ExpensesModel;

})