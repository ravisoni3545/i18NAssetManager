define([ "backbone", "app" ], function(Backbone, app) {
	var OpportunitySearchModel = Backbone.Model.extend({

		defaults : {
			
		}
	});

	return OpportunitySearchModel;

})