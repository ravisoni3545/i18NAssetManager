define([ "backbone", "app" ], function(Backbone, app) {
	var MyClosingModel = Backbone.Model.extend({

	
	

	});

	return MyClosingModel;

})