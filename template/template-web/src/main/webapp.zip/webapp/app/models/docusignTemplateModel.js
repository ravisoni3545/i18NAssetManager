define(["backbone","app"],function(Backbone,app){
	var DocusignTemplateModel = Backbone.Model.extend({
		initialize: function() {
		}
	});
	return DocusignTemplateModel;
});