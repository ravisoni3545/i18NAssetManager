define(["backbone", "app"],function(Backbone, app){
	var OpportunityPropertiesModel=Backbone.Model.extend({
		defaults : {
		}
	});
	return OpportunityPropertiesModel;

});