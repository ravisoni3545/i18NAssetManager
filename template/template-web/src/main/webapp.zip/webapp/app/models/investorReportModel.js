define([ "backbone", "app" ], function(Backbone, app) {
	var investorReportModel = Backbone.Model.extend({

		initialize: function () {

        },
		defaults : {
			
		}
		
	});

	return investorReportModel;

});