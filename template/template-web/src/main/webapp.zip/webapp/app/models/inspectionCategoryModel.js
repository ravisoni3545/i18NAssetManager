define(["backbone", "app"],function(Backbone, app){
	var inspectionCategoryModel=Backbone.Model.extend({
		defaults : {
		}
	});
	return inspectionCategoryModel;
});