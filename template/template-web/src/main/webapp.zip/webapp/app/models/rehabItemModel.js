define(["backbone", "app"],function(Backbone, app){
	var RehabItemModel=Backbone.Model.extend({
		defaults : {
		}
	});
	return RehabItemModel;
});