define(["backbone", "app"],function(Backbone, app){
	var RehabRepairModel=Backbone.Model.extend({
		defaults : {
		}
	});
	return RehabRepairModel;

});