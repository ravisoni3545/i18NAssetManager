/**
 * Created by santosh on 3/31/14.
 */
require(['config'], function() {
	require(['loginmain'], function() {

	}); 
}   
);