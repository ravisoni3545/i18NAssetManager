
	({
		  cssIn: 'all.css',
		  out: 'all.min.css',
		  optimizeCss: 'default'
		})
